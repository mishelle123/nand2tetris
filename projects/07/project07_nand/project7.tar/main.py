
import  Translator as T
import  sys
import os
import ntpath
if __name__ == '__main__':


  path = sys.argv[1]
  print (path)
  t = T.Translator()
  t.Translate(path)





